//Codigo por Jose Antonio Aleman
//A01196565
//Desarrollo de Aplicaciones Web
const weather = require('./weather.js');
const city = "guadalupe";

weather.getWeather(city);